window.operationData = window.operationData || {};
window.operationData["슌·프론티어"] = {
    "basic": [
        {
            "label": "의식 0",
            "value": "총격+3 › 총격+2 › 총격+3 › 총격+2 › 총격+3 › 총격+2"
        },
        {
            "label": "의식 2",
            "value": "총격+3 › 2+총격+1 › 총격+3 › 2+총격+1 › 총격+3 › 2+총격+1"
        }
    ],
    "basic_en": [
        {
            "label": "A0",
            "value": "Gun+3 › Gun+2 › Gun+3 › Gun+2 › Gun+3 › Gun+2"
        },
        {
            "label": "A2",
            "value": "Gun+3 › 2+Gun+1 › Gun+3 › 2+Gun+1 › Gun+3 › 2+Gun+1"
        }
    ],
    "basic_jp": [
        {
            "label": "意識 0",
            "value": "銃撃+3 › 銃撃+2 › 銃撃+3 › 銃撃+2 › 銃撃+3 › 銃撃+2"
        },
        {
            "label": "意識 2",
            "value": "銃撃+3 › 2+銃撃+1 › 銃撃+3 › 2+銃撃+1 › 銃撃+3 › 2+銃撃+1"
        }
    ],
    "note": [
        ""
    ]
};

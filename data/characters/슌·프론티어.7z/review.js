(function () {
    window.characterReview = window.characterReview || {};
    window.characterReview["슌·프론티어"] = { name_en: "Shun Kano·Frontier", name_jp: "加納 駿·フロンティア", codename: "SOY·FRONTIER",
        review: ``,
        review_en: ``,
        review_jp: ``,
        pros: [
          ""
        ],
        pros_en: [
          ""
        ],
        pros_jp: [
          ""
        ],
        cons: [
          ""
        ],
        cons_en: [
          ""
        ],
        cons_jp: [
          ""
        ],
    };
})();



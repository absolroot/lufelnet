window.basicStatsData = window.basicStatsData || {};
window.basicStatsData["슌·프론티어"] = {
    "a0_lv1": {
        "HP": 0,
        "SP": 100,
        "attack": 0,
        "defense": 0,
        "crit_rate": 5,
        "crit_mult": 150,
        "speed": 102
    },
    "awake7": {
        "HP_per": 29.0
    },
    "a0_lv80": {
        "HP": 4350.03,
        "attack": 850.03,
        "defense": 579.99
    },
    "a1_lv80": {
        "HP": 4428.43,
        "attack": 865.23,
        "defense": 590.39
    },
    "a2_lv80": {
        "HP": 4506.83,
        "attack": 880.43,
        "defense": 600.79
    },
    "a3_lv80": {
        "HP": 4585.23,
        "attack": 895.63,
        "defense": 611.19
    },
    "a4_lv80": {
        "HP": 4663.63,
        "attack": 911.63,
        "defense": 621.59
    },
    "a5_lv80": {
        "HP": 4741.23,
        "attack": 926.83,
        "defense": 631.99
    },
    "a6_lv80": {
        "HP": 4819.63,
        "attack": 942.03,
        "defense": 642.39
    }
};
